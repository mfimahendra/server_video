from ftplib import FTP, error_perm

host = '10.109.32.55'
port = 21
username = 'MIRAI'
password = 'Ymp!Mis@123'
root = 'mivid'

def connect_ftp():
    ftp = FTP()
    try:
        ftp.connect(host, port)
        ftp.login(user=username, passwd=password)
        ftp.cwd(root)
    except error_perm as e:
        print(f"FTP error: {e}")
        ftp.quit()
        return None
    return ftp

def get_video(video_idx):
    ftp = connect_ftp()
    if ftp is None:
        return "Failed to connect to FTP server."

    try:
        video_path = f"{video_idx}.mp4"
        with open(video_path, 'wb') as f:
            ftp.retrbinary(f"RETR {video_path}", f.write)
    except error_perm as e:
        return f"FTP error: {e}"
    except Exception as e:
        return f"Error: {e}"
    finally:
        ftp.quit()    
    return video_path

def get_local_video(video_idx):
    # /var/services/homes/MIRAI/mitube_server this is the path of the server

    # /var/services/homes/MIRAI/mivid this is the path of the video
    video_path = f"/var/services/homes/MIRAI/mivid/{video_idx}.mp4"
    return video_path