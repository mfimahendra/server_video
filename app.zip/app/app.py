from flask import Flask, Response, jsonify, request, send_file, current_app, Blueprint
from flask_cors import CORS, cross_origin

import os
import re

from .errors import errors
from .controller.mitube import get_video, get_local_video


app = Flask(__name__)
app.register_blueprint(errors)


# Configure Flask-CORS
cors = CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True, allow_headers=["x-csrf-token"])


@app.route("/")
def index():
    responses = {
        "status": 200,
        "message": "MIRAI VIDEO SERVER API",
    }
    return jsonify(responses)


# @app.route("/stream/<video_idx>", methods=["GET"])
# def video(video_idx):    
#     video_path = get_local_video(video_idx)

#     def generate(video_path):
#             with open(video_path, 'rb') as video_file:
#                 while chunk := video_file.read(1024):  # Adjust chunk size as needed
#                     yield chunk

#     video_name = os.path.basename(video_path)
#     video_size = os.path.getsize(video_path)
#     video_type = 'video/mp4'  # Adjust MIME type as needed

#     headers = {
#         'Content-Type': video_type,
#         'Content-Length': str(video_size),
#         'Content-Disposition': f'inline; filename="{video_name}"',
#         'Accept-Ranges': 'bytes',
#         'Cache-Control': 'public, must-revalidate, max-age=0',
#         'Pragma': 'public',
#     }

#     return Response(generate(video_path), headers=headers)

@app.route("/stream/<video_idx>", methods=["GET"])
def video(video_idx):    
    video_path = get_local_video(video_idx)

    if not os.path.exists(video_path):
        return Response("Video not found.", status=404)

    video_name = os.path.basename(video_path)
    video_size = os.path.getsize(video_path)
    video_type = 'video/mp4'  # Adjust MIME type as needed

    range_header = request.headers.get('Range', None)
    user_agent = request.headers.get('User-Agent', '')

    def generate(start, end):
        with open(video_path, 'rb') as video_file:
            video_file.seek(start)
            while start <= end:
                chunk_size = min(1024, end - start + 1)
                chunk = video_file.read(chunk_size)
                if not chunk:
                    break
                start += len(chunk)
                yield chunk

    # Check if the request is from a mobile device (basic user-agent check)
    is_mobile = "Mobi" in user_agent or "iPad" in user_agent

    if range_header:
        # Parse the range header to get the start and end of the requested range
        range_match = re.match(r"bytes=(\d+)-(\d*)", range_header)
        if range_match:
            start = int(range_match.group(1))
            end = range_match.group(2)
            if end:
                end = int(end)
            else:
                end = video_size - 1
        else:
            # If the range cannot be parsed, respond with 416 (Range Not Satisfiable)
            # abort(416)
            return Response("Range Not Satisfiable", status=416)
        
        # Respond with the partial content
        headers = {
            'Content-Type': video_type,
            'Content-Range': f"bytes {start}-{end}/{video_size}",
            'Content-Length': str(end - start + 1),
            'Accept-Ranges': 'bytes',
            'Content-Disposition': f'inline; filename="{video_name}"',
        }
        return Response(generate(start, end), status=206, headers=headers)
    
    # Return the entire video for devices that don't request ranges (or for mobile fallback)
    headers = {
        'Content-Type': video_type,
        'Content-Length': str(video_size),
        'Content-Disposition': f'inline; filename="{video_name}"',
        'Accept-Ranges': 'bytes',
    }

    if is_mobile:
        # Special handling for mobile devices if needed
        headers['Cache-Control'] = 'public, max-age=3600'  # Adjust as needed
    
    return Response(generate(0, video_size - 1), headers=headers)

@app.route("/clear_cache", methods=["GET"])
def clear_cache():
    for file in os.listdir():
        if re.search(r"\d+\.mp4", file):
            os.remove(file)
    return Response("Cache cleared.", status=200)

@app.route("/health")
def health():
    return Response("OK", status=200)
